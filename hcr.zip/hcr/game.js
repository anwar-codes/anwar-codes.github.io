/* Hill Ride: Supra X — game.js
   ------------------------------------------------------------------
   HTML5 prototype mirip Hill Climb Racing dengan fisika 2D nyata
   menggunakan Planck.js (port Box2D). Desain modular dan rapi.
   - Fisika: wheel joint (suspensi + motor), torsi tilt, gesekan tanah
   - Terrain: edge chain procedural (kombinasi sinus + jitter)
   - Kontrol: keyboard + on-screen (pointer/touch), mobile friendly
   - Render: Canvas2D, world-to-screen transform dgn kamera follow
   - Kinerja: fixed timestep (60 Hz) + accumulator
   ------------------------------------------------------------------ */

(function () {
  'use strict';

  const pl = window.planck;

  // ---------- Konstanta & skala dunia ----------
  const SCALE = 60;           // 1m = 60px
  const GRAVITY_Y = -20;      // m/s^2 (ke bawah)
  const DT = 1 / 60;
  const VELOCITY_IT = 8;
  const POSITION_IT = 3;

  const BIKE = {
    chassisW: 1.6,
    chassisH: 0.45,
    wheelR: 0.36,
    mass: 130,
    suspHzFront: 4.0,
    suspHzRear:  3.4,
    suspDamp:    0.7,
    motorMaxSpeed: 28,     // rad/s (~268 RPM)
    motorMaxTorque: 220,   // N·m
    tiltTorque: 200,       // N·m
  };

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

  let DPR = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
  let viewW = 0, viewH = 0;
  function resize() {
    DPR = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    viewW = window.innerWidth; viewH = window.innerHeight;
    canvas.width = Math.floor(viewW * DPR);
    canvas.height = Math.floor(viewH * DPR);
    ctx.setTransform(1,0,0,1,0,0);
    ctx.scale(DPR, DPR);
  }
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);
  resize();

  // ---------- Dunia fisika ----------
  const world = new pl.World(pl.Vec2(0, GRAVITY_Y));

  const TERRAIN = {
    length: 3000, step: 2.0, baseY: 0.0,
    amp1: 0.8, amp2: 0.35, k1: 0.06, k2: 0.23, jitter: 0.25,
    friction: 1.4,
  };

  const terrain = { body: world.createBody({ type: 'static' }), verts: [] };

  (function buildTerrain() {
    const verts = [];
    for (let x = 0; x <= TERRAIN.length; x += TERRAIN.step) {
      const h = (Math.sin(x * TERRAIN.k1) * TERRAIN.amp1) +
                (Math.sin(x * TERRAIN.k2 + 1.7) * TERRAIN.amp2) +
                (noise1D(x * 0.1) - 0.5) * TERRAIN.jitter;
      verts.push(pl.Vec2(x, h));
    }
    terrain.verts = verts;

    for (let i = 0; i < verts.length - 1; i++) {
      const edge = pl.Edge(verts[i], verts[i + 1]);
      terrain.body.createFixture({ shape: edge, density: 0, friction: TERRAIN.friction, restitution: 0 });
    }
    const floor = world.createBody();
    floor.createFixture(pl.Edge(pl.Vec2(-50, -50), pl.Vec2(TERRAIN.length + 50, -50)), { friction: 1.0 });
  })();

  const bike = {};
  (function buildBike() {
    const startX = 4, startY = 2.8;

    const chassis = world.createBody({
      type: 'dynamic',
      position: pl.Vec2(startX, startY),
      linearDamping: 0.08, angularDamping: 0.15,
    });
    chassis.createFixture({
      shape: pl.Box(BIKE.chassisW * 0.5, BIKE.chassisH * 0.5),
      density: BIKE.mass / (BIKE.chassisW * BIKE.chassisH * 80), friction: 0.6,
    });
    const headShape = pl.Box(BIKE.chassisW * 0.22, BIKE.chassisH * 0.18, pl.Vec2(BIKE.chassisW * 0.42, 0.02), 0.05);
    chassis.createFixture({ shape: headShape, density: 0.3, friction: 0.5 });

    const r = BIKE.wheelR;
    const wheelRear  = world.createBody({ type: 'dynamic', position: pl.Vec2(startX - 0.55 * BIKE.chassisW * 0.5, startY - 0.55) });
    const wheelFront = world.createBody({ type: 'dynamic', position: pl.Vec2(startX + 0.65 * BIKE.chassisW * 0.5, startY - 0.55) });
    wheelRear.createFixture({ shape: pl.Circle(r), density: 2.0, friction: 1.6 });
    wheelFront.createFixture({ shape: pl.Circle(r), density: 2.0, friction: 1.6 });

    const axis = pl.Vec2(0, 1);
    const jr = world.createJoint(pl.WheelJoint({
      motorSpeed: 0, maxMotorTorque: BIKE.motorMaxTorque, enableMotor: true,
      frequencyHz: BIKE.suspHzRear, dampingRatio: BIKE.suspDamp
    }, chassis, wheelRear, wheelRear.getPosition(), axis));

    const jf = world.createJoint(pl.WheelJoint({
      motorSpeed: 0, maxMotorTorque: 0, enableMotor: false,
      frequencyHz: BIKE.suspHzFront, dampingRatio: BIKE.suspDamp
    }, chassis, wheelFront, wheelFront.getPosition(), axis));

    bike.chassis = chassis; bike.wheelRear = wheelRear; bike.wheelFront = wheelFront;
    bike.jointRear = jr; bike.jointFront = jf;
  })();

  // ---------- Input ----------
  const input = { throttle: 0, brake: 0, tiltL: 0, tiltR: 0 };

  function keyToAction(e, down) {
    const k = e.key.toLowerCase();
    if (['arrowup','w',' '].includes(k)) input.throttle = down ? 1 : 0;
    if (['arrowdown','s'].includes(k))   input.brake    = down ? 1 : 0;
    if (['arrowleft','a'].includes(k))   input.tiltL    = down ? 1 : 0;
    if (['arrowright','d'].includes(k))  input.tiltR    = down ? 1 : 0;
    if (k === 'p' && down) paused = !paused;
  }
  window.addEventListener('keydown', (e) => {
    if ([' ', 'ArrowUp', 'ArrowDown'].includes(e.key)) e.preventDefault();
    keyToAction(e, true);
  }, { passive: false });
  window.addEventListener('keyup', (e) => keyToAction(e, false), { passive: true });

  const pads = document.querySelectorAll('#controls .pad');
  const activePointers = new Map();
  function setPad(action, down) {
    if (action === 'throttle') input.throttle = down ? 1 : 0;
    if (action === 'brake')    input.brake    = down ? 1 : 0;
    if (action === 'tiltL')    input.tiltL    = down ? 1 : 0;
    if (action === 'tiltR')    input.tiltR    = down ? 1 : 0;
  }
  pads.forEach(btn => {
    const action = btn.dataset.action;
    btn.addEventListener('pointerdown', (e) => {
      e.preventDefault(); btn.setPointerCapture(e.pointerId);
      activePointers.set(e.pointerId, action); setPad(action, true);
    });
    btn.addEventListener('pointerup', (e) => {
      const act = activePointers.get(e.pointerId); setPad(act, false); activePointers.delete(e.pointerId);
    });
    btn.addEventListener('pointercancel', (e) => {
      const act = activePointers.get(e.pointerId); setPad(act, false); activePointers.delete(e.pointerId);
    });
  });

  let paused = false;
  document.addEventListener('visibilitychange', () => { if (document.hidden) paused = true; });

  // ---------- Kamera ----------
  const camera = { x: 0, y: 0, lerp: 0.12, update(tx, ty){ this.x += (tx - this.x)*this.lerp; this.y += (ty - this.y)*this.lerp; } };

  // ---------- HUD ----------
  const elSpeed = document.getElementById('speed');
  const elDist  = document.getElementById('distance');
  const elRPM   = document.getElementById('rpm');

  let acc = 0, lastMs = performance.now(), startX = bike.chassis.getPosition().x;
  function loop(now) {
    const dt = Math.min(0.033, (now - lastMs) / 1000); lastMs = now;
    if (!paused) { acc += dt; while (acc >= DT) { step(DT); acc -= DT; } }
    render(); requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  function step(dt) {
    // Throttle/Brake -> motor speed (rad/s) + torque
    const rear = bike.jointRear;
    let targetOmega = BIKE.motorMaxSpeed * (input.throttle - 0.85 * input.brake);
    let torque = BIKE.motorMaxTorque;
    if (input.brake > 0 && input.throttle === 0) { targetOmega = 0; torque = BIKE.motorMaxTorque * (0.6 + 0.4 * input.brake); }
    rear.setMotorSpeed(targetOmega);
    rear.setMaxMotorTorque(torque);
    rear.enableMotor(true);

    // Tilt control -> torsi rangka
    const chassis = bike.chassis;
    const tilt = (input.tiltR - input.tiltL);
    if (Math.abs(tilt) > 0.0001) chassis.applyTorque(BIKE.tiltTorque * tilt, true);

    world.step(dt, VELOCITY_IT, POSITION_IT);

    // Kamera & HUD
    const pos = chassis.getPosition();
    camera.update(pos.x + 2.0, Math.max(1.0, pos.y + 0.6));

    const v = chassis.getLinearVelocity();
    elSpeed.textContent = Math.abs(v.x * 3.6).toFixed(0);
    elDist.textContent  = Math.max(0, pos.x - startX).toFixed(1);
    const rpm = Math.abs(bike.wheelRear.getAngularVelocity()) * 60 / (2 * Math.PI);
    elRPM.textContent = rpm.toFixed(0);
  }

  function render() {
    const W = viewW, H = viewH;
    ctx.clearRect(0, 0, W, H);

    ctx.save();
    const cx = W * 0.4, cy = H * 0.6;
    ctx.translate(cx, cy);
    ctx.scale(SCALE, -SCALE);
    ctx.translate(-camera.x, -camera.y);

    drawParallax();
    drawTerrain();
    drawBike();

    ctx.restore();
  }

  function drawParallax() {
    ctx.save();
    ctx.globalAlpha = 0.5; ctx.strokeStyle = '#bfe6ff'; ctx.lineWidth = 0.04;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      const y0 = -0.8 - i * 0.6;
      for (let x = camera.x - 20; x <= camera.x + 30; x += 0.2) {
        const y = y0 + Math.sin(x * 0.12 + i) * 0.2, X = x * 0.6 + i * 5;
        if (x === camera.x - 20) ctx.moveTo(X, y); else ctx.lineTo(X, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawTerrain() {
    ctx.save();
    ctx.lineWidth = 0.08; ctx.strokeStyle = '#70b65c'; ctx.fillStyle = '#94cd7c';
    ctx.beginPath();
    for (let i = 0; i < terrain.verts.length; i++) {
      const v = terrain.verts[i]; if (i === 0) ctx.moveTo(v.x, v.y); else ctx.lineTo(v.x, v.y);
    }
    const last = terrain.verts[terrain.verts.length - 1];
    ctx.lineTo(last.x, -10); ctx.lineTo(terrain.verts[0].x, -10); ctx.closePath(); ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < terrain.verts.length; i++) {
      const v = terrain.verts[i]; const Y = v.y + 0.01;
      if (i === 0) ctx.moveTo(v.x, Y); else ctx.lineTo(v.x, Y);
    }
    ctx.stroke();
    ctx.restore();
  }

  function drawBike() {
    drawWheel(bike.wheelRear, '#333');
    drawWheel(bike.wheelFront, '#333');

    const b = bike.chassis; const p = b.getPosition(); const a = b.getAngle();
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-a);

    ctx.fillStyle = '#1f6feb';
    const w = BIKE.chassisW, h = BIKE.chassisH;
    ctx.fillRect(-w/2, -h/2, w, h);

    ctx.fillStyle = '#222'; ctx.fillRect(-w*0.05, h*0.05, w*0.4, h*0.18);
    ctx.fillStyle = '#0f4bb8'; ctx.fillRect(w*0.30, -h*0.15, w*0.35, h*0.3);

    ctx.strokeStyle = '#d0d6e0'; ctx.lineWidth = 0.04;
    ctx.beginPath(); ctx.moveTo(-w*0.35, -h*0.05); ctx.lineTo(-w*0.05, -h*0.12); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w*0.42, h*0.12); ctx.lineTo(w*0.15, h*0.22); ctx.stroke();

    ctx.restore();
  }

  function drawWheel(w, color) {
    const p = w.getPosition(), a = w.getAngle(), r = BIKE.wheelR;
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-a);
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#eaeaea'; ctx.lineWidth = 0.02; ctx.beginPath(); ctx.arc(0, 0, r*0.8, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); for (let i = 0; i < 6; i++) { const t = i * Math.PI / 3; ctx.moveTo(0, 0); ctx.lineTo(Math.cos(t)*r*0.8, Math.sin(t)*r*0.8); } ctx.stroke();
    ctx.restore();
  }

  function noise1D(x) { const n = Math.sin(x * 12.9898) * 43758.5453; return n - Math.floor(n); }

  /* Dokumentasi Fisika:
     1) Unit & Skala: Box2D stabil di 0.1–10m. Dengan SCALE=60 px/m, motor & terrain proporsional.
     2) WheelJoint: suspensi (frequencyHz, dampingRatio) + motor (motorSpeed, maxMotorTorque).
        Axis (0,1) => suspensi bergerak vertikal relatif rangka. Rear: enableMotor=true.
     3) Throttle/Brake: throttle → motorSpeed positif; rem tanpa throttle menahan roda (speed≈0) dgn torque besar.
     4) Tilt: Body.applyTorque ke rangka agar bisa koreksi pitch saat di udara/tanjakan.
     5) Terrain: edge fixtures beruntun (chain). Friction tinggi untuk traksi; profil: sinus ganda + jitter.
     6) Timestep: fixed 1/60 dgn accumulator untuk konsistensi lintas device.
  */
})();